#!/bin/sh
# ---------------------------------------------------------------
# GUARDARE EVENTSDIRECTOR MICROSERVICE INSTALLER
# ©2026 VistaTech, Inc. ALL RIGHTS RESERVED
# ---------------------------------------------------------------

set -e

# COLORS
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# CONFIGURATION
SERVICE_NAME="eventsDirector"
SERVICE_USER="vistatech"
SERVICE_GROUP="vistatech"
BINARY_NAME="eventsDirector"
SYSTEMD_UNIT="eventsDirector.service"
TOP_DIR="/usr/bin/com.vistatechgso"
INSTALL_DIR="${TOP_DIR}/${SERVICE_NAME}"
DB_NAME="eventsDirectorDb"
DB_USER="guardare"

echo ""
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${CYAN}  Guardare ${SERVICE_NAME} Microservice Installer${NC}"
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# PREFLIGHT — MUST RUN AS ROOT OR WITH SUDO
if [ "$(id -u)" -ne 0 ]; then
    echo "${RED}[ERROR]${NC} This installer must be run as root or with sudo."
    exit 1
fi

# PREFLIGHT — CHECK THAT BINARY EXISTS IN CURRENT DIRECTORY
if [ ! -f "./${BINARY_NAME}" ]; then
    echo "${RED}[ERROR]${NC} ${BINARY_NAME} binary not found in current directory."
    echo "       Make sure you are running install.sh from the package directory."
    exit 1
fi

# STEP 1: STOP EXISTING SERVICE (IF RUNNING)
echo "${YELLOW}[1/8]${NC} Checking for existing ${SERVICE_NAME} installation..."
if systemctl is-active --quiet "${SYSTEMD_UNIT}" 2>/dev/null; then
    echo "       Stopping ${SERVICE_NAME} service..."
    systemctl stop "${SYSTEMD_UNIT}"
    sleep 3
    echo "       ${GREEN}Service stopped.${NC}"
elif pgrep -x "${BINARY_NAME}" > /dev/null 2>&1; then
    echo "       Stopping ${SERVICE_NAME} process..."
    killall -q -TERM "${BINARY_NAME}" 2>/dev/null || true
    sleep 3
    echo "       ${GREEN}Process stopped.${NC}"
else
    echo "       No existing ${SERVICE_NAME} process found — clean install."
fi

# STEP 2: CREATE INSTALLATION DIRECTORIES
echo "${YELLOW}[2/8]${NC} Creating installation directories..."
mkdir -p "${TOP_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${TOP_DIR}"
mkdir -p "${INSTALL_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
echo "       ${GREEN}Done.${NC}"

# STEP 3: COPY PACKAGE CONTENTS
echo "${YELLOW}[3/8]${NC} Copying package contents to ${INSTALL_DIR}..."
cp -pfR ./* "${INSTALL_DIR}/"
chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
chmod 755 "${INSTALL_DIR}/${BINARY_NAME}"
echo "       ${GREEN}Done.${NC}"

# STEP 4: PRESERVE serviceConfig.yaml (DON'T OVERWRITE EXISTING)
echo "${YELLOW}[4/8]${NC} Checking serviceConfig.yaml..."
CONFIG_FILE="${TOP_DIR}/serviceConfig.yaml"
if [ -f "${CONFIG_FILE}" ]; then
    echo "       Existing serviceConfig.yaml found — ${GREEN}preserving.${NC}"
else
    if [ -f "${INSTALL_DIR}/installResources/serviceConfig.yaml" ]; then
        cp -p "${INSTALL_DIR}/installResources/serviceConfig.yaml" "${CONFIG_FILE}"
        chown "${SERVICE_USER}:${SERVICE_GROUP}" "${CONFIG_FILE}"
        echo "       Default serviceConfig.yaml installed — ${YELLOW}edit before starting.${NC}"
    else
        echo "       ${YELLOW}No serviceConfig.yaml found — you will need to create one manually.${NC}"
    fi
fi

# STEP 5: INSTALL SYSTEMD SERVICE
echo "${YELLOW}[5/8]${NC} Installing systemd service..."
if [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" ]; then
    mv "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}"
    cp -p "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" "/etc/systemd/system/${SYSTEMD_UNIT}"
    chown root:root "/etc/systemd/system/${SYSTEMD_UNIT}"
    chmod 644 "/etc/systemd/system/${SYSTEMD_UNIT}"
    systemctl daemon-reload
    systemctl enable "${SYSTEMD_UNIT}"
    echo "       ${GREEN}Done.${NC}"
elif [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" ]; then
    cp -p "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" "/etc/systemd/system/${SYSTEMD_UNIT}"
    chown root:root "/etc/systemd/system/${SYSTEMD_UNIT}"
    chmod 644 "/etc/systemd/system/${SYSTEMD_UNIT}"
    systemctl daemon-reload
    systemctl enable "${SYSTEMD_UNIT}"
    echo "       ${GREEN}Done.${NC}"
else
    echo "       ${RED}[ERROR]${NC} ${SYSTEMD_UNIT}.sh not found in installResources/"
    echo "       Systemd service was not installed. You will need to configure it manually."
fi

# STEP 6: SETUP EVENTSDIRECTOR DATABASE
echo "${YELLOW}[6/8]${NC} Setting up ${DB_NAME} in MariaDB..."

# Prefer mariadb client, fall back to mysql
MYSQL_CMD=""
if command -v mariadb > /dev/null 2>&1; then
    MYSQL_CMD="mariadb"
elif command -v mysql > /dev/null 2>&1; then
    MYSQL_CMD="mysql"
fi

if [ -z "${MYSQL_CMD}" ]; then
    echo "       ${RED}[ERROR]${NC} MariaDB client not found — skipping DB setup."
    echo "       ${YELLOW}You will need to create ${DB_NAME} and grant ${DB_USER} manually.${NC}"
elif ! ${MYSQL_CMD} -u root -e "SELECT 1;" > /dev/null 2>&1; then
    echo "       ${RED}[ERROR]${NC} Cannot connect to MariaDB as root — skipping DB setup."
    echo "       ${YELLOW}Run manually: sudo ${MYSQL_CMD} -u root${NC}"
    echo "       ${YELLOW}  CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;${NC}"
    echo "       ${YELLOW}  GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';${NC}"
    echo "       ${YELLOW}  FLUSH PRIVILEGES;${NC}"
else
    # Verify guardare user exists before granting
    USER_EXISTS=$(${MYSQL_CMD} -u root -N -B -e "SELECT COUNT(*) FROM mysql.user WHERE User='${DB_USER}' AND Host='localhost';" 2>/dev/null || echo "0")
    if [ "${USER_EXISTS}" = "0" ]; then
        echo "       ${RED}[ERROR]${NC} MariaDB user '${DB_USER}'@'localhost' does not exist."
        echo "       ${YELLOW}Ensure Normalizer/Collector is installed first (creates guardare user).${NC}"
    else
        SQL_SCRIPT="
CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
"
        if echo "${SQL_SCRIPT}" | ${MYSQL_CMD} -u root > /dev/null 2>&1; then
            echo "       ${GREEN}Database ${DB_NAME} ready; ${DB_USER}@localhost granted.${NC}"
        else
            echo "       ${RED}Database setup failed. Check: journalctl -u mariadb${NC}"
        fi
    fi
fi

# STEP 7: START SERVICE
echo "${YELLOW}[7/8]${NC} Starting ${SERVICE_NAME} service..."
if systemctl start "${SYSTEMD_UNIT}" 2>/dev/null; then
    sleep 2
    if systemctl is-active --quiet "${SYSTEMD_UNIT}"; then
        echo "       ${GREEN}${SERVICE_NAME} is running.${NC}"
    else
        echo "       ${RED}${SERVICE_NAME} failed to start. Check: journalctl -u ${SYSTEMD_UNIT}${NC}"
    fi
else
    echo "       ${RED}Failed to start ${SERVICE_NAME}. Check: journalctl -u ${SYSTEMD_UNIT}${NC}"
fi

# STEP 8: CLEAN UP INSTALLATION ARTIFACTS
echo "${YELLOW}[8/8]${NC} Cleaning up installation files..."
rm -rf "${INSTALL_DIR}/installResources"
rm -f "${INSTALL_DIR}/install.sh"
echo "       ${GREEN}Done.${NC}"

# SUMMARY
echo ""
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${GREEN}  ${SERVICE_NAME} installation complete.${NC}"
echo ""
echo "  Install dir:  ${INSTALL_DIR}"
echo "  Config file:  ${CONFIG_FILE}"
echo "  Service:      ${SYSTEMD_UNIT}"
echo "  Database:     ${DB_NAME} (user: ${DB_USER}@localhost)"
echo ""
echo "  Useful commands:"
echo "    sudo systemctl status ${SYSTEMD_UNIT}"
echo "    sudo journalctl -u ${SYSTEMD_UNIT} -f"
echo "    sudo systemctl restart ${SYSTEMD_UNIT}"
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

exit 0