[Unit]
Description="Events Director Microservice"
After=network-online.target mariadb.service
Wants=network-online.target
Requires=mariadb.service

[Service]
Type=simple
ExecStart=/usr/bin/com.vistatechgso/eventsDirector/eventsDirector -ghp=3000 -rp=60000 -d=1
ExecStop=/bin/kill -s TERM $MAINPID
KillMode=process
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target