#!/bin/sh
# ---------------------------------------------------------------
# GUARDARE VCOLLECTOR MICROSERVICE INSTALLER
# ©2026 VistaTech, Inc. ALL RIGHTS RESERVED
# ---------------------------------------------------------------

set -e

# COLORS
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# CONFIGURATION
SERVICE_NAME="vCollector"
SERVICE_USER="vistatech"
SERVICE_GROUP="vistatech"
BINARY_NAME="vCollector"
SYSTEMD_UNIT="vcollector.service"
TOP_DIR="/usr/bin/com.vistatechgso"
INSTALL_DIR="${TOP_DIR}/${SERVICE_NAME}"

echo ""
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${CYAN}  Guardare ${SERVICE_NAME} Microservice Installer${NC}"
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# OPTIONS (second cloudLink drop, Sep 15 — the zero-touch first install)
#   --cloud=<file>   the console's cloud: block (Provision Collector → the block shown at
#                    provisioning), saved to a file on this box; "-" reads it from stdin.
#                    With no serviceConfig.yaml on the box yet, the installer writes one that
#                    holds ONLY that block: vCollector boots in bootstrap mode, heartbeats,
#                    pulls the console's serviceConfig.yaml, writes it and restarts on it.
#   --force-cloud    replace an existing serviceConfig.yaml with the bootstrap file
#                    (the old file is kept as serviceConfig.yaml.bak-<timestamp>)
#   --console=<url>       (third cloudLink drop, Sep 15 — calling home) the console's address, e.g.
#   --enroll-key=<key>    https://admin.guardare.io, and the platform enrollment key from Cloud
#                         Management → Configuration → Collector enrollment. With no serviceConfig.yaml
#                         on the box the installer writes one holding ONLY an enroll: block: vCollector
#                         calls home until an operator provisions it under Collector Provisioning →
#                         New Collectors Ready for Provisioning, is handed its cloud: block, and boots
#                         into bootstrap mode as with --cloud. Run with neither flag on a box without a
#                         serviceConfig.yaml, the installer asks for both (the key is not echoed).
CLOUD_SRC=""
FORCE_CLOUD=0
CONSOLE_URL=""
ENROLL_KEY=""
for arg in "$@"; do
    case "$arg" in
        --cloud=*) CLOUD_SRC="${arg#--cloud=}" ;;
        --force-cloud) FORCE_CLOUD=1 ;;
        --console=*) CONSOLE_URL="${arg#--console=}" ;;
        --enroll-key=*) ENROLL_KEY="${arg#--enroll-key=}" ;;
        -h|--help)
            echo "usage: sudo ./install.sh [--console=<url> --enroll-key=<key>] [--cloud=<cloud-block-file>|--cloud=-] [--force-cloud]"
            exit 0 ;;
        *) echo "${RED}[ERROR]${NC} unknown option: $arg"; exit 1 ;;
    esac
done

# PREFLIGHT — MUST RUN AS ROOT OR WITH SUDO
if [ "$(id -u)" -ne 0 ]; then
    echo "${RED}[ERROR]${NC} This installer must be run as root or with sudo."
    exit 1
fi

# PREFLIGHT — THE CLOUD BLOCK, WHEN GIVEN, MUST BE ONE
CLOUD_BLOCK=""
if [ -n "${CLOUD_SRC}" ]; then
    if [ "${CLOUD_SRC}" = "-" ]; then
        CLOUD_BLOCK="$(cat)"
    elif [ -f "${CLOUD_SRC}" ]; then
        CLOUD_BLOCK="$(cat "${CLOUD_SRC}")"
    else
        echo "${RED}[ERROR]${NC} --cloud: ${CLOUD_SRC} is not a file (use - for stdin)."
        exit 1
    fi
    if ! printf '%s\n' "${CLOUD_BLOCK}" | grep -q '^cloud:'; then
        echo "${RED}[ERROR]${NC} --cloud: the text has no top-level 'cloud:' line — paste the block exactly as the console shows it."
        exit 1
    fi
    for key in tenant collectorId wsUrl apiUrl token; do
        if ! printf '%s\n' "${CLOUD_BLOCK}" | grep -Eq "^[[:space:]]+${key}:"; then
            echo "${RED}[ERROR]${NC} --cloud: the block has no '${key}:' line."
            exit 1
        fi
    done
fi

# PREFLIGHT — CALLING HOME: the console address + enrollment key (flags, or asked for on a fresh box)
CONFIG_FILE_EARLY="${TOP_DIR}/serviceConfig.yaml"
if [ -z "${CLOUD_SRC}" ] && [ ! -f "${CONFIG_FILE_EARLY}" ] && { [ -n "${CONSOLE_URL}" ] || [ -n "${ENROLL_KEY}" ] || [ -t 0 ]; }; then
    if [ -z "${CONSOLE_URL}" ] && [ -t 0 ]; then
        printf '%s' "       Console address (e.g. https://admin.guardare.io): "
        read CONSOLE_URL
    fi
    if [ -n "${CONSOLE_URL}" ] && [ -z "${ENROLL_KEY}" ] && [ -t 0 ]; then
        printf '%s' "       Enrollment key (Cloud Management → Configuration → Collector enrollment; not echoed): "
        stty -echo 2>/dev/null || true
        read ENROLL_KEY
        stty echo 2>/dev/null || true
        echo ""
    fi
fi
ENROLL_API=""
if [ -n "${CONSOLE_URL}" ] || [ -n "${ENROLL_KEY}" ]; then
    if [ -z "${CONSOLE_URL}" ] || [ -z "${ENROLL_KEY}" ]; then
        echo "${RED}[ERROR]${NC} calling home needs both --console=<url> and --enroll-key=<key>."
        exit 1
    fi
    case "${CONSOLE_URL}" in
        http://*|https://*) ;;
        *) echo "${RED}[ERROR]${NC} --console: ${CONSOLE_URL} must start with https:// (or http://)."; exit 1 ;;
    esac
    case "${ENROLL_KEY}" in
        genr_*) ;;
        *) echo "${RED}[ERROR]${NC} --enroll-key: that is not an enrollment key (they start with genr_) — copy it from Cloud Management → Configuration."; exit 1 ;;
    esac
    ENROLL_API="$(printf '%s' "${CONSOLE_URL}" | sed 's#/*$##')"
    case "${ENROLL_API}" in
        */api/v1) ;;
        *) ENROLL_API="${ENROLL_API}/api/v1" ;;
    esac
    # reachability only — a POST without a key is answered 401 by a console that is there; no row is created
    if command -v curl >/dev/null 2>&1; then
        PROBE="$(curl -sS -m 10 -o /dev/null -w '%{http_code}' -X POST -H 'Content-Type: application/json' -d '{}' "${ENROLL_API}/enroll" 2>/dev/null || echo 000)"
        case "${PROBE}" in
            401|422|429) echo "       Console reachable at ${ENROLL_API} ${GREEN}(ok)${NC}" ;;
            000) echo "${RED}[ERROR]${NC} ${ENROLL_API} could not be reached from this box (DNS / firewall / TLS) — check the address and the network, then run the installer again."; exit 1 ;;
            *) echo "       ${YELLOW}[WARN]${NC} ${ENROLL_API}/enroll answered HTTP ${PROBE} — is that the Guardare console? Continuing; vCollector keeps calling and logs the reply." ;;
        esac
    fi
fi

# PREFLIGHT — CHECK THAT BINARY EXISTS IN CURRENT DIRECTORY
if [ ! -f "./${BINARY_NAME}" ]; then
    echo "${RED}[ERROR]${NC} ${BINARY_NAME} binary not found in current directory."
    echo "       Make sure you are running install.sh from the package directory."
    exit 1
fi

# STEP 1: STOP EXISTING SERVICE (IF RUNNING)
echo "${YELLOW}[1/7]${NC} Checking for existing ${SERVICE_NAME} installation..."
if systemctl is-active --quiet "${SYSTEMD_UNIT}" 2>/dev/null; then
    echo "       Stopping ${SERVICE_NAME} service..."
    systemctl stop "${SYSTEMD_UNIT}"
    sleep 3
    echo "       ${GREEN}Service stopped.${NC}"
elif pgrep -x "${BINARY_NAME}" > /dev/null 2>&1; then
    echo "       Stopping ${SERVICE_NAME} process..."
    killall -q -TERM "${BINARY_NAME}" 2>/dev/null || true
    sleep 3
    echo "       ${GREEN}Process stopped.${NC}"
else
    echo "       No existing ${SERVICE_NAME} process found — clean install."
fi

# STEP 2: CREATE INSTALLATION DIRECTORIES
echo "${YELLOW}[2/7]${NC} Creating installation directories..."
mkdir -p "${TOP_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${TOP_DIR}"
mkdir -p "${INSTALL_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
echo "       ${GREEN}Done.${NC}"

# STEP 3: COPY PACKAGE CONTENTS
echo "${YELLOW}[3/7]${NC} Copying package contents to ${INSTALL_DIR}..."
cp -pfR ./* "${INSTALL_DIR}/"
chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
chmod 755 "${INSTALL_DIR}/${BINARY_NAME}"
echo "       ${GREEN}Done.${NC}"

# STEP 4: PRESERVE serviceConfig.yaml (DON'T OVERWRITE EXISTING) — OR WRITE THE BOOTSTRAP FILE
echo "${YELLOW}[4/7]${NC} Checking serviceConfig.yaml..."
CONFIG_FILE="${TOP_DIR}/serviceConfig.yaml"
write_bootstrap_config() {
    {
        echo "---"
        echo "# GUARDARE SERVICE CONFIGURATION FILE — BOOTSTRAP"
        echo "# Written by install.sh --cloud on $(date -u +%Y-%m-%dT%H:%M:%SZ)."
        echo "# This file holds ONLY the cloud link. vCollector boots in bootstrap mode, reports to the"
        echo "# console, pulls the serviceConfig.yaml the console renders for this collector, writes it"
        echo "# here (keeping this cloud: block) and restarts on it. Nothing here needs editing by hand."
        echo ""
        printf '%s\n' "${CLOUD_BLOCK}"
    } > "${CONFIG_FILE}"
    chown "${SERVICE_USER}:${SERVICE_GROUP}" "${CONFIG_FILE}"
    chmod 600 "${CONFIG_FILE}"
}
write_enroll_config() {
    {
        echo "---"
        echo "# GUARDARE SERVICE CONFIGURATION FILE — CALLING HOME"
        echo "# Written by install.sh --console/--enroll-key on $(date -u +%Y-%m-%dT%H:%M:%SZ)."
        echo "# This collector is not provisioned yet. vCollector calls the console with this key until an"
        echo "# operator provisions it (Collector Provisioning → New Collectors Ready for Provisioning); the"
        echo "# console then hands it its cloud: block, which replaces this file, and it boots in bootstrap mode."
        echo "# Nothing here needs editing by hand."
        echo ""
        echo "enroll:"
        echo "  apiUrl: \"${ENROLL_API}\""
        echo "  key: \"${ENROLL_KEY}\""
    } > "${CONFIG_FILE}"
    chown "${SERVICE_USER}:${SERVICE_GROUP}" "${CONFIG_FILE}"
    chmod 600 "${CONFIG_FILE}"
}
if [ -f "${CONFIG_FILE}" ] && [ -n "${CLOUD_BLOCK}" ] && [ "${FORCE_CLOUD}" -eq 1 ]; then
    BAK="${CONFIG_FILE}.bak-$(date -u +%Y%m%d%H%M%S)"
    cp -p "${CONFIG_FILE}" "${BAK}"
    write_bootstrap_config
    echo "       Existing serviceConfig.yaml kept as $(basename "${BAK}") — ${GREEN}bootstrap file written${NC} (--force-cloud)."
elif [ -f "${CONFIG_FILE}" ]; then
    echo "       Existing serviceConfig.yaml found — ${GREEN}preserving.${NC}"
    if [ -n "${CLOUD_BLOCK}" ]; then
        echo "       ${YELLOW}--cloud ignored${NC}: the box already has a serviceConfig.yaml (use --force-cloud to replace it with the bootstrap file)."
    fi
    if [ -n "${ENROLL_API}" ]; then
        echo "       ${YELLOW}--console/--enroll-key ignored${NC}: the box already has a serviceConfig.yaml (remove it first to enrol this box afresh)."
    fi
elif [ -n "${CLOUD_BLOCK}" ]; then
    write_bootstrap_config
    echo "       ${GREEN}Bootstrap serviceConfig.yaml written${NC} — only the cloud: block; the console pushes the rest at the first heartbeat."
elif [ -n "${ENROLL_API}" ]; then
    write_enroll_config
    echo "       ${GREEN}Calling-home serviceConfig.yaml written${NC} — vCollector calls ${ENROLL_API} until this collector is provisioned on the console."
else
    if [ -f "${INSTALL_DIR}/installResources/serviceConfig.yaml" ]; then
        cp -p "${INSTALL_DIR}/installResources/serviceConfig.yaml" "${CONFIG_FILE}"
        chown "${SERVICE_USER}:${SERVICE_GROUP}" "${CONFIG_FILE}"
        echo "       Default serviceConfig.yaml installed — ${YELLOW}edit before starting.${NC}"
    else
        echo "       ${YELLOW}No serviceConfig.yaml found — you will need to create one manually.${NC}"
    fi
fi

# STEP 5: INSTALL SYSTEMD SERVICE
echo "${YELLOW}[5/7]${NC} Installing systemd service..."
if [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" ]; then
    mv "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}"
    cp -p "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" "/etc/systemd/system/${SYSTEMD_UNIT}"
    chown root:root "/etc/systemd/system/${SYSTEMD_UNIT}"
    chmod 644 "/etc/systemd/system/${SYSTEMD_UNIT}"
    systemctl daemon-reload
    systemctl enable "${SYSTEMD_UNIT}"
    echo "       ${GREEN}Done.${NC}"
elif [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" ]; then
    cp -p "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" "/etc/systemd/system/${SYSTEMD_UNIT}"
    chown root:root "/etc/systemd/system/${SYSTEMD_UNIT}"
    chmod 644 "/etc/systemd/system/${SYSTEMD_UNIT}"
    systemctl daemon-reload
    systemctl enable "${SYSTEMD_UNIT}"
    echo "       ${GREEN}Done.${NC}"
else
    echo "       ${RED}[ERROR]${NC} ${SYSTEMD_UNIT}.sh not found in installResources/"
    echo "       Systemd service was not installed. You will need to configure it manually."
fi

# STEP 6: START SERVICE
echo "${YELLOW}[6/7]${NC} Starting ${SERVICE_NAME} service..."
if systemctl start "${SYSTEMD_UNIT}" 2>/dev/null; then
    sleep 2
    if systemctl is-active --quiet "${SYSTEMD_UNIT}"; then
        echo "       ${GREEN}${SERVICE_NAME} is running.${NC}"
    else
        echo "       ${RED}${SERVICE_NAME} failed to start. Check: journalctl -u ${SYSTEMD_UNIT}${NC}"
    fi
else
    echo "       ${RED}Failed to start ${SERVICE_NAME}. Check: journalctl -u ${SYSTEMD_UNIT}${NC}"
fi

# STEP 7: CLEAN UP INSTALLATION ARTIFACTS
echo "${YELLOW}[7/7]${NC} Cleaning up installation files..."
rm -rf "${INSTALL_DIR}/installResources"
rm -f "${INSTALL_DIR}/install.sh"
echo "       ${GREEN}Done.${NC}"

# SUMMARY
echo ""
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "${GREEN}  ${SERVICE_NAME} installation complete.${NC}"
echo ""
echo "  Install dir:  ${INSTALL_DIR}"
echo "  Config file:  ${CONFIG_FILE}"
if [ -n "${CLOUD_BLOCK}" ]; then
    echo "  Bootstrap:    the console pushes the full serviceConfig.yaml at the first heartbeat"
    echo "                (watch it: sudo journalctl -u ${SYSTEMD_UNIT} -f | grep cloudLink)"
fi
if [ -n "${ENROLL_API}" ] && [ ! -f "${CONFIG_FILE}.bak" ] && grep -q '^enroll:' "${CONFIG_FILE}" 2>/dev/null; then
    echo "  Calling home: this collector now appears under Collector Provisioning → New Collectors"
    echo "                Ready for Provisioning on the console; click Provision there — the box"
    echo "                receives its cloud: block on its next call and boots into bootstrap mode"
    echo "                (watch it: sudo journalctl -u ${SYSTEMD_UNIT} -f | grep cloudLink)"
fi
echo "  Service:      ${SYSTEMD_UNIT}"
echo ""
echo "  Useful commands:"
echo "    sudo systemctl status ${SYSTEMD_UNIT}"
echo "    sudo journalctl -u ${SYSTEMD_UNIT} -f"
echo "    sudo systemctl restart ${SYSTEMD_UNIT}"
echo "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

exit 0