[Unit]
Description=vCollector Microservice
After=network-online.target normalizer.service
Wants=network-online.target normalizer.service
StartLimitIntervalSec=0

[Service]
Type=simple
ExecStart=/usr/bin/com.vistatechgso/vCollector/vCollector -d=1 -doevents=200 -ld=true
Restart=always
RestartSec=10
User=root
StandardOutput=journal
StandardError=journal
SyslogIdentifier=vcollector
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target