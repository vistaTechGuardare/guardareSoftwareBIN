[Unit]
Description="HuduSync Microservice"
After=network-online.target mariadb.service
Wants=network-online.target
Requires=mariadb.service

[Service]
Type=simple
User=vistatech
Group=vistatech
ExecStart=/usr/bin/com.vistatechgso/HuduSync/HuduSync -d=1
ExecStop=/bin/kill -s TERM $MAINPID
KillMode=process
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target