[Unit]
Description="LogCollector Microservice"
After=network-online.target mariadb.service
Wants=network-online.target
Requires=mariadb.service

[Service]
Type=simple
User=vistatech
Group=vistatech
ExecStart=/usr/bin/com.vistatechgso/LogCollector/LogCollector -d=1
ExecStop=/bin/kill -s TERM $MAINPID
KillMode=process
Restart=always
RestartSec=10
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
