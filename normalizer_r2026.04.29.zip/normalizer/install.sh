#!/bin/sh
# ---------------------------------------------------------------
# GUARDARE NORMALIZER MICROSERVICE INSTALLER
# (c)2026 VistaTech, Inc. ALL RIGHTS RESERVED
# ---------------------------------------------------------------
#
# Runs AFTER guardare-provision.sh has set up the OS:
#   - Ubuntu 24.04 base + Xojo runtime libs
#   - MariaDB installed, 'guardare' user created, DBs created
#   - File-descriptor limits + TCP tuning + systemd safety nets
#
# This installer is responsible ONLY for the Normalizer microservice:
#   - Stop vCollector (VC-001 race protection)
#   - Stop any running normalizer process
#   - Copy package files into /usr/bin/com.vistatechgso/normalizer/
#   - Install the systemd unit
#   - Install the memory guardrail drop-in (OOM-001)
#   - Run any SQL migrations from ./SQL/*.sql alphabetically
#   - Start the service AND wait for it to bind on 127.0.0.1:8411
#   - Start vCollector back up
#
# VC-001 (May 2026): vCollector is stopped at Step 1 and restarted at
# Step 9. This prevents vCollector's reconnect loop from racing
# Normalizer's BindAndListen(8411) during the install window. Without
# this protection, every Normalizer install was a coin flip on any
# host with vCollector already running. See GitHub issue #29.
#
# OOM-001 (Jun 2026): a memory guardrail drop-in (MemoryMax) is installed
# alongside the unit at Step 6b so a runaway allocation in Normalizer is
# cgroup-killed and restarted in seconds, rather than exhausting host RAM
# and starving every service's heartbeat on the box. This is the
# operational backstop to the findAllKeyValues array-size guard (the
# code-level fix). See Step 6b.
#
# It does NOT touch serviceConfig.yaml. That file is managed
# out-of-band (manual edit or GitHub-distributed template).
#
# USAGE:
#   sudo ./install.sh
# ---------------------------------------------------------------

set -e

# COLORS
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# CONFIGURATION
SERVICE_NAME="normalizer"
SERVICE_USER="vistatech"
SERVICE_GROUP="vistatech"
BINARY_NAME="normalizer"
SYSTEMD_UNIT="normalizer.service"
TOP_DIR="/usr/bin/com.vistatechgso"
INSTALL_DIR="${TOP_DIR}/${SERVICE_NAME}"
CFG_DIR="${INSTALL_DIR}/CFG"
SQL_DIR="${INSTALL_DIR}/SQL"
CONFIG_FILE="${TOP_DIR}/serviceConfig.yaml"

# VC-001: vCollector unit name and bind-wait timeout.
VCOLLECTOR_UNIT="vcollector.service"
BIND_WAIT_TIMEOUT=30  # seconds to wait for Normalizer to bind on 8411

# VC-001: track whether we stopped vCollector so we know whether to restart it.
# An operator running this installer on a Normalizer-only host (no vCollector
# co-located) should not see vCollector started spuriously.
VCOLLECTOR_WAS_RUNNING=0

# OOM-001: Normalizer cgroup memory guardrail (see Step 6b). Healthy
# Normalizer RSS is ~110MB, so 2G is enormous headroom — it only ever
# trips on a genuine runaway. Tune here for hosts with different RAM.
MEMORY_MAX="2G"      # hard cap — cgroup-kill + systemd restart instead of host-wide OOM
MEMORY_HIGH="1500M"  # soft throttle (memory reclaim pressure) below the hard cap

echo ""
echo "${CYAN}===================================================${NC}"
echo "${CYAN}  Guardare ${SERVICE_NAME} Microservice Installer${NC}"
echo "${CYAN}===================================================${NC}"
echo ""

# ---------------------------------------------------------------
# PREFLIGHT
# ---------------------------------------------------------------

if [ "$(id -u)" -ne 0 ]; then
    echo "${RED}[ERROR]${NC} This installer must be run as root or with sudo."
    exit 1
fi

if [ ! -f "./${BINARY_NAME}" ]; then
    echo "${RED}[ERROR]${NC} ${BINARY_NAME} binary not found in current directory."
    echo "       Run install.sh from the unpacked package directory."
    exit 1
fi

# ---------------------------------------------------------------
# STEP 1: STOP vCOLLECTOR (VC-001 race protection)
# ---------------------------------------------------------------
#
# vCollector's reconnect loop fires up to ~5 connection attempts per
# second whenever Normalizer is unreachable. If one of those attempts
# lands during Normalizer's BindAndListen(8411) window, the kernel
# may assign 8411 as vCollector's source port, blocking Normalizer's
# bind permanently. See GitHub issue #29 (VC-001).
#
# Stopping vCollector now and restarting at Step 9 closes the race
# at the operational level. The vCollector source-port-bind fix
# (ClientPort = 47411) closes it at the code level.
# ---------------------------------------------------------------

echo "${YELLOW}[1/10]${NC} Stopping vCollector (VC-001 race protection)..."
if systemctl is-active --quiet "${VCOLLECTOR_UNIT}" 2>/dev/null; then
    systemctl stop "${VCOLLECTOR_UNIT}"
    VCOLLECTOR_WAS_RUNNING=1
    # Brief drain for any in-flight connect() to clear the kernel.
    sleep 2
    echo "       ${GREEN}vCollector stopped.${NC}"
else
    echo "       vCollector not running - no race to protect against."
fi

# ---------------------------------------------------------------
# STEP 2: STOP EXISTING NORMALIZER SERVICE
# ---------------------------------------------------------------

echo "${YELLOW}[2/10]${NC} Checking for existing ${SERVICE_NAME} installation..."
if systemctl is-active --quiet "${SYSTEMD_UNIT}" 2>/dev/null; then
    echo "       Stopping ${SERVICE_NAME} service..."
    systemctl stop "${SYSTEMD_UNIT}"
    sleep 3
    echo "       ${GREEN}Service stopped.${NC}"
elif pgrep -x "${BINARY_NAME}" > /dev/null 2>&1; then
    echo "       Stopping ${SERVICE_NAME} process..."
    killall -q -TERM "${BINARY_NAME}" 2>/dev/null || true
    sleep 3
    echo "       ${GREEN}Process stopped.${NC}"
else
    echo "       No existing ${SERVICE_NAME} process found - clean install."
fi

# ---------------------------------------------------------------
# STEP 3: CREATE INSTALLATION DIRECTORIES
# ---------------------------------------------------------------

echo "${YELLOW}[3/10]${NC} Creating installation directories..."
mkdir -p "${TOP_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${TOP_DIR}"
mkdir -p "${INSTALL_DIR}" "${CFG_DIR}" "${SQL_DIR}"
chown "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}" "${CFG_DIR}" "${SQL_DIR}"
echo "       ${GREEN}Done.${NC}"

# ---------------------------------------------------------------
# STEP 4: COPY PACKAGE CONTENTS
# ---------------------------------------------------------------

echo "${YELLOW}[4/10]${NC} Copying package contents to ${INSTALL_DIR}..."
cp -pfR ./* "${INSTALL_DIR}/"
chown -R "${SERVICE_USER}:${SERVICE_GROUP}" "${INSTALL_DIR}"
chmod 755 "${INSTALL_DIR}/${BINARY_NAME}"
echo "       ${GREEN}Done.${NC}"

# ---------------------------------------------------------------
# STEP 5: PRESERVE serviceConfig.yaml
# ---------------------------------------------------------------
#
# serviceConfig.yaml lives at ${TOP_DIR}/serviceConfig.yaml and is
# the shared config for all microservices on this host. It is NOT
# managed by this installer - operator or GitHub template owns it.
# This step is informational only.
# ---------------------------------------------------------------

echo "${YELLOW}[5/10]${NC} Checking serviceConfig.yaml..."
if [ -f "${CONFIG_FILE}" ]; then
    echo "       ${GREEN}Found:${NC} ${CONFIG_FILE}"
else
    echo "       ${YELLOW}WARNING:${NC} ${CONFIG_FILE} not found."
    echo "       Place it before starting the service or service will fail."
fi

# ---------------------------------------------------------------
# STEP 6: INSTALL SYSTEMD UNIT
# ---------------------------------------------------------------

echo "${YELLOW}[6/10]${NC} Installing systemd unit..."
UNIT_SRC=""
if [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" ]; then
    mv "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}.sh" \
       "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}"
    UNIT_SRC="${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}"
elif [ -f "${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}" ]; then
    UNIT_SRC="${INSTALL_DIR}/installResources/${SYSTEMD_UNIT}"
fi

if [ -n "${UNIT_SRC}" ]; then
    cp -p "${UNIT_SRC}" "/etc/systemd/system/${SYSTEMD_UNIT}"
    chown root:root "/etc/systemd/system/${SYSTEMD_UNIT}"
    chmod 644 "/etc/systemd/system/${SYSTEMD_UNIT}"
    systemctl daemon-reload
    systemctl enable "${SYSTEMD_UNIT}" 2>/dev/null
    echo "       ${GREEN}Done.${NC}"
else
    echo "       ${RED}[ERROR]${NC} ${SYSTEMD_UNIT} not found in installResources/"
    echo "       Systemd service not installed. Configure manually if needed."
fi

# ---------------------------------------------------------------
# STEP 6b: INSTALL MEMORY GUARDRAIL DROP-IN (OOM-001)
# ---------------------------------------------------------------
#
# OOM-001 (Jun 2026): a single pathological envelope drove
# findAllKeyValues into an unbounded allocation. Normalizer's RSS
# climbed to ~13.8GB, exhausted host RAM, filled swap, and was
# OOM-killed after a ~2h silent balloon that put the whole box into
# memory pressure and froze every service's heartbeat. The
# findAllKeyValues array-size + depth guards are the code-level fix;
# this cgroup cap is defense in depth.
#
# MemoryMax is the hard wall: a future runaway is killed inside the
# service's own cgroup and restarted by systemd (Restart=always,
# RestartSec=3) in seconds, instead of dragging the entire host into
# memory pressure. MemoryHigh is the soft throttle (memory reclaim
# pressure) that slows a climb before it reaches the hard cap.
#
# Delivered as a drop-in (not baked into the unit) so per-host RAM
# tuning is a one-line change and the core unit stays generic. The
# drop-in is written before daemon-reload so the cap is active for
# the very first start of the freshly installed service at Step 8.
# ---------------------------------------------------------------

echo "${YELLOW}[6b/10]${NC} Installing memory guardrail drop-in (OOM-001)..."
DROPIN_DIR="/etc/systemd/system/${SYSTEMD_UNIT}.d"
mkdir -p "${DROPIN_DIR}"
cat > "${DROPIN_DIR}/memory.conf" <<EOF
# Guardare Normalizer memory guardrail — OOM-001 (Jun 2026)
# Managed by install.sh (Step 6b). Hard cap so a runaway allocation is a
# few-second single-service restart, not a host-wide memory-pressure outage.
[Service]
MemoryMax=${MEMORY_MAX}
MemoryHigh=${MEMORY_HIGH}
EOF
chown root:root "${DROPIN_DIR}/memory.conf"
chmod 644 "${DROPIN_DIR}/memory.conf"
systemctl daemon-reload
echo "       ${GREEN}Done. (MemoryMax=${MEMORY_MAX}, MemoryHigh=${MEMORY_HIGH})${NC}"

# ---------------------------------------------------------------
# STEP 7: RUN SQL MIGRATIONS (./SQL/*.sql alphabetically)
# ---------------------------------------------------------------
#
# No-op if no .sql files present. Migrations should be idempotent
# (CREATE IF NOT EXISTS / ALTER ... IF NOT EXISTS) so re-running
# on upgrades is safe.
#
# Authenticates with the local 'guardare' MariaDB user. Password
# is read from ${CONFIG_FILE} database.password if available,
# otherwise the migration step is SKIPPED with a warning - the
# Normalizer binary's auto-migration on first run will handle
# table-level changes anyway.
# ---------------------------------------------------------------

echo "${YELLOW}[7/10]${NC} Running SQL migrations..."

DB_PASS=""
if [ -f "${CONFIG_FILE}" ]; then
    if command -v yq >/dev/null 2>&1; then
        DB_PASS=$(yq '.database.password // ""' "${CONFIG_FILE}" 2>/dev/null | tr -d '"')
    else
        DB_PASS=$(awk '/^database:/{f=1;next} f && /^[a-zA-Z]/{f=0} f && /password:/{print $2; exit}' \
                  "${CONFIG_FILE}" 2>/dev/null | tr -d '"')
    fi
fi

SQL_FILES=""
if [ -d "${SQL_DIR}" ]; then
    SQL_FILES=$(ls "${SQL_DIR}"/*.sql 2>/dev/null | sort)
fi

if [ -z "${SQL_FILES}" ]; then
    echo "       No .sql files found in ${SQL_DIR} - skipping."
elif [ -z "${DB_PASS}" ]; then
    echo "       ${YELLOW}SKIPPED:${NC} Cannot read database password from serviceConfig.yaml."
    echo "       Apply migrations manually:"
    for sql_file in ${SQL_FILES}; do
        echo "         mariadb -u guardare -p < ${sql_file}"
    done
else
    MIGRATION_OK=1
    for sql_file in ${SQL_FILES}; do
        sql_basename=$(basename "${sql_file}")
        echo "       Applying ${sql_basename}..."
        if mariadb -u guardare -p"${DB_PASS}" < "${sql_file}" 2>&1; then
            echo "       ${GREEN}${sql_basename} applied.${NC}"
        else
            echo "       ${RED}${sql_basename} FAILED.${NC}"
            MIGRATION_OK=0
            break
        fi
    done
    if [ "${MIGRATION_OK}" -eq 0 ]; then
        echo "${RED}[ERROR]${NC} A migration failed. Service NOT started."
        echo "       Fix the failing .sql file and re-run installer."
        # VC-001: don't leave vCollector stopped on error exit if we stopped it.
        if [ "${VCOLLECTOR_WAS_RUNNING}" -eq 1 ]; then
            echo "       Restarting vCollector since install aborted..."
            systemctl start "${VCOLLECTOR_UNIT}" 2>/dev/null || true
        fi
        exit 1
    fi
fi

# ---------------------------------------------------------------
# STEP 8: START NORMALIZER + WAIT FOR BIND
# ---------------------------------------------------------------
#
# VC-001: vCollector remains stopped until we confirm Normalizer
# has bound on 127.0.0.1:8411. Poll journalctl for the bind-success
# log line rather than a blind sleep so we adapt to slow hosts
# (Celeron J4125 takes ~13s; faster hosts complete in 3-5s).
#
# Timeout: BIND_WAIT_TIMEOUT seconds (30 by default). If exceeded,
# we restart vCollector anyway so the host isn't left in a half-up
# state, but flag the failure prominently in the summary.
# ---------------------------------------------------------------

echo "${YELLOW}[8/10]${NC} Starting ${SERVICE_NAME} service..."
NORMALIZER_BOUND=0

if systemctl start "${SYSTEMD_UNIT}" 2>/dev/null; then
    sleep 2
    if systemctl is-active --quiet "${SYSTEMD_UNIT}"; then
        echo "       ${SERVICE_NAME} process started. Waiting for bind on 127.0.0.1:8411..."

        # Poll journalctl for the bind-success log line. The line shape comes
        # from normalizerChilkatListener_Class.startListening() and reads:
        #   (LISTENER) Chilkat listener bound on 127.0.0.1:8411 ...
        for i in $(seq 1 ${BIND_WAIT_TIMEOUT}); do
            if journalctl -u "${SYSTEMD_UNIT}" --since "60 seconds ago" \
                 --output=cat 2>/dev/null | \
                 grep -q "Chilkat listener bound on 127.0.0.1:8411"; then
                NORMALIZER_BOUND=1
                echo "       ${GREEN}Listener bound after ${i}s.${NC}"
                break
            fi
            sleep 1
        done

        if [ "${NORMALIZER_BOUND}" -eq 0 ]; then
            echo "       ${RED}Listener did NOT bind within ${BIND_WAIT_TIMEOUT}s.${NC}"
            echo "       Check:  journalctl -u ${SYSTEMD_UNIT} -n 50"
        fi
    else
        echo "       ${RED}${SERVICE_NAME} failed to start.${NC}"
        echo "       Check:  journalctl -u ${SYSTEMD_UNIT} -n 50"
    fi
else
    echo "       ${RED}Failed to start ${SERVICE_NAME}.${NC}"
    echo "       Check:  journalctl -u ${SYSTEMD_UNIT} -n 50"
fi

# ---------------------------------------------------------------
# STEP 9: RESTART vCOLLECTOR
# ---------------------------------------------------------------
#
# Only restart vCollector if it was running at the start of this
# installer. Hosts without vCollector co-located shouldn't see
# vCollector started spuriously.
# ---------------------------------------------------------------

echo "${YELLOW}[9/10]${NC} Restarting vCollector..."
if [ "${VCOLLECTOR_WAS_RUNNING}" -eq 1 ]; then
    if [ "${NORMALIZER_BOUND}" -eq 0 ]; then
        echo "       ${YELLOW}WARNING:${NC} Normalizer did not bind, but starting vCollector anyway."
        echo "       vCollector will reconnect once Normalizer recovers."
    fi
    if systemctl start "${VCOLLECTOR_UNIT}" 2>/dev/null; then
        sleep 2
        if systemctl is-active --quiet "${VCOLLECTOR_UNIT}"; then
            echo "       ${GREEN}vCollector started.${NC}"
        else
            echo "       ${RED}vCollector failed to start.${NC}"
            echo "       Check:  journalctl -u ${VCOLLECTOR_UNIT} -n 50"
        fi
    else
        echo "       ${RED}Failed to start vCollector.${NC}"
        echo "       Check:  journalctl -u ${VCOLLECTOR_UNIT} -n 50"
    fi
else
    echo "       vCollector was not running at install start - leaving stopped."
fi

# ---------------------------------------------------------------
# STEP 10: CLEANUP
# ---------------------------------------------------------------

echo "${YELLOW}[10/10]${NC} Cleaning up installer artifacts..."
rm -rf "${INSTALL_DIR}/installResources"
rm -f "${INSTALL_DIR}/install.sh"
echo "       ${GREEN}Done.${NC}"

# ---------------------------------------------------------------
# SUMMARY
# ---------------------------------------------------------------

echo ""
echo "${CYAN}===================================================${NC}"
echo "${GREEN}  ${SERVICE_NAME} installation complete.${NC}"
echo ""
echo "  Install dir:  ${INSTALL_DIR}"
echo "  Config file:  ${CONFIG_FILE}"
echo "  CFG dir:      ${CFG_DIR}"
echo "  SQL dir:      ${SQL_DIR}"
echo "  Service:      ${SYSTEMD_UNIT}"
echo "  Memory cap:   MemoryMax=${MEMORY_MAX}  MemoryHigh=${MEMORY_HIGH}  (OOM-001)"
echo ""

# VC-001: bind status callout. If Normalizer didn't bind, the operator
# needs to know loudly - this is the failure mode that drove the ticket.
if [ "${NORMALIZER_BOUND}" -eq 0 ] && systemctl is-active --quiet "${SYSTEMD_UNIT}"; then
    echo "  ${RED}WARNING:${NC} Normalizer process is running but listener bind was NOT"
    echo "  confirmed within ${BIND_WAIT_TIMEOUT}s. Verify with:"
    echo "    sudo ss -tlnp | grep 8411"
    echo "    sudo journalctl -u ${SYSTEMD_UNIT} -n 50"
    echo ""
fi

echo "  Useful commands:"
echo "    sudo systemctl status ${SYSTEMD_UNIT}"
echo "    sudo journalctl -u ${SYSTEMD_UNIT} -f"
echo "    sudo systemctl restart ${SYSTEMD_UNIT}"
echo "    sudo systemctl show ${SYSTEMD_UNIT} -p MemoryMax -p MemoryHigh"
echo "${CYAN}===================================================${NC}"
echo ""

exit 0