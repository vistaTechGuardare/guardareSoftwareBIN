[Unit]
Description=Normalizer Microservice
After=network-online.target mariadb.service
Wants=network-online.target
Requires=mariadb.service

[Service]
Type=simple
ExecStart=/usr/bin/com.vistatechgso/normalizer/normalizer -d=1
# VC-001: was Restart=on-failure — flipped to always so bind-failure-exit-0
# gets retried. The Normalizer-side bind retry loop (NORM-XXX) is the proper
# fix; this is defense in depth.
Restart=always
RestartSec=3
User=root
StandardOutput=journal
StandardError=journal
SyslogIdentifier=normalizer

[Install]
WantedBy=multi-user.target